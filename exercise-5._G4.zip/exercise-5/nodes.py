
from bokeh.io import curdoc
from bokeh.layouts import row, widgetbox
from bokeh.models import ColumnDataSource, LabelSet
from bokeh.models.widgets import Slider, TextInput
import networkx as nx

from bokeh.models import Plot, Range1d, MultiLine, Circle, HoverTool, TapTool, BoxSelectTool, SaveTool, ResetTool, BoxZoomTool
from bokeh.models.graphs import from_networkx, NodesAndLinkedEdges, EdgesAndLinkedNodes
from bokeh.palettes import Spectral4

import warnings
warnings.filterwarnings('ignore')

G = nx.readwrite.graphml.read_graphml('./sheep_ml.graphml')
ages = nx.get_node_attributes(G,'age')
weights = nx.get_edge_attributes(G,'weight')

init_age = 1
init_weight = 1
max_weight = max([(value, key) for key, value in weights.items()])[0]
max_age = max([(value, key) for key, value in ages.items()])[0]
red_sheep = []

def update_wcolor(wids, widths, weight, red_sheep):
    wfill_color = []

    for v,i in zip(wids, widths):
        #print 'v', v, i, red_sheep
        if i == weight and v in red_sheep:
            wfill_color.append('#000000')
            continue

        wfill_color.append('#bdbdbd')

    return wfill_color

def update_color(node, edge, age, weight):
    fcolor = []
    red_sheep = []
    blue_sheep = []

    for i in node.nodes(data=True):
        if i[1]['age'] == age:
            red_sheep.append(i[0])

    for (s, t, w) in edge.edges(data=True):
        if s in red_sheep and w['weight'] == weight:
            blue_sheep.append(t)

    for i in node.nodes(data=True):
        if i[0] in red_sheep:
            fcolor.append('#d95f02') # matching age and source
        elif i[0] in blue_sheep:
            fcolor.append('#7570b3') # target
        else:
            fcolor.append('#1b9e77')

    return fcolor, red_sheep

def get_width(edge):
    wids = []
    widths = []
    start = []
    end = []

    for i in edge.edges(data=True):
        wids.append(i[0])
        widths.append(i[2]['weight'])
        start.append(i[0])
        end.append(i[1])
        
    return wids, widths, start, end

def get_ages(edges):
    for i in edges.nodes(data=True):
        i[1].update({'age':ages[i[0]]})
        
    return edges
    
def get_nodes(weight, age):
    aG = G.subgraph([n for n,attrdict in G.node.items() if attrdict['age'] >= age])

    incoming = []
    outgoing = []

    for (u,v,d) in aG.edges(data=True):
        incoming.append((v,u))

    for (u,v,d) in aG.edges(data=True):
        if (u,v) in incoming:
            continue
 
        if d['weight'] >= weight:
            outgoing.append((u,v,d))

    eG = nx.Graph(outgoing)
    return aG, eG

nodeG, edgeG = get_nodes(init_weight, init_age) # init

# Set up plot
plot = Plot(plot_width=600, plot_height=600, x_range=Range1d(-1.1,1.1), y_range=Range1d(-1.1,1.1))
plot.title.text = "Female Bighorn Sheep Dominance"
plot.add_tools(HoverTool(tooltips=None), TapTool(), BoxSelectTool(), SaveTool(), ResetTool(), BoxZoomTool())

# Set up widgets
text = TextInput(title="Title", value='My sheep network')
age = Slider(title="Sheep Age", value=1, start=1, end=max_age, step=1)
age.value = init_age

weight = Slider(title="Edge Weight", value=1, start=1, end=max_weight, step=1)
weight.value = init_weight

# initial add
# node section
npos = nx.circular_layout(nodeG)
graph = from_networkx(nodeG, nx.circular_layout, scale=1, center=(0,0))

fill_color, red_sheep = update_color(nodeG, edgeG, age.value, weight.value)
wids, widths, start, end = get_width(edgeG)
wfill_color = update_wcolor(wids, widths, weight.value, red_sheep)
current_age = [i[1]['age'] for i in nodeG.nodes(data=True)]
sizes = [3 + 5 * i for i in current_age]
#print ('init widths', len(widths), len(start), len(end))

graph.edge_renderer.data_source.add(widths, name="widths")
graph.edge_renderer.data_source.add(start, name="start")
graph.edge_renderer.data_source.add(end, name="end")

graph.edge_renderer.data_source.add(wfill_color, name="wfill_color")

sheep = [i[0] for i in nodeG.nodes(data=True)]
x,y=zip(*npos.values())

source = ColumnDataSource(dict(index=sheep, sheep=sheep, sizes=sizes, age=current_age, fill_color=fill_color, x=x, y=y))
labels = LabelSet(x='x', y='y', text='sheep', source=source)

def update_graph(node, edge, weight, age, red_sheep):
    wids, widths, start, end = get_width(edge)
    #print ('widths', len(widths), 'start', len(start), 'end', len(end))

    cage = [i[1]['age'] for i in node.nodes(data=True)]
    sizes = [3 + 5 * i for i in cage]  # set this aside for sizes

    fill_color, red_sheep = update_color(node, edge, age, weight)
    wfill_color = update_wcolor(wids, widths, weight, red_sheep)

    npos = nx.circular_layout(node)
    x,y = zip(*npos.values())
    sheep = [i[0] for i in node.nodes(data=True)]

    graph.edge_renderer.data_source.data.update({'start':start, 'end':end, 'widths':widths, 'wfill_color':wfill_color})

    # node section
    graph.node_renderer.data_source.data.update({'index':sheep, 'sizes':sizes, 'age':cage, 'fill_color':fill_color})

    source = ColumnDataSource(dict(sheep=sheep, x=x, y=y))
    labels.update(x='x',y='y',text='sheep',source=source)


graph.node_renderer.glyph = Circle(size="sizes", fill_color="fill_color")
graph.node_renderer.data_source.add(fill_color, name='fill_color')
graph.node_renderer.data_source.add(sizes, name='sizes')
graph.node_renderer.selection_glyph = Circle(size=15, fill_color=Spectral4[2])
graph.node_renderer.hover_glyph = Circle(size=15, fill_color=Spectral4[1])
graph.node_renderer.glyph.properties_with_values()

# edge section
graph.edge_renderer.glyph = MultiLine(line_alpha=0.8, line_width="widths", line_color="wfill_color")
graph.edge_renderer.selection_glyph = MultiLine(line_color=Spectral4[2], line_width="widths")
graph.edge_renderer.hover_glyph = MultiLine(line_color=Spectral4[1], line_width="widths")
graph.selection_policy = NodesAndLinkedEdges()
graph.inspection_policy = EdgesAndLinkedNodes()

plot.renderers.append(graph)
plot.renderers.append(labels)

# Set up callbacks
def update_title(attrname, old, new):
    plot.title.text = text.value

text.on_change('value', update_title)

def update_data(attrname, old, new):
    #node, edge = get_nodes(weight.value, age.value)
    update_graph(nodeG, edgeG, weight.value, age.value, red_sheep)

for w in [age, weight]:
    w.on_change('value', update_data)

# Set up layouts and add to document
inputs = widgetbox(text, age, weight)

curdoc().add_root(row(inputs, plot, width=800))
curdoc().title = "Bighorn Sheep"
