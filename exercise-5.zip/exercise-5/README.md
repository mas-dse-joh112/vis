
1. From terminal (command prompt), issue the following command from this root folder to start the bokeh app

bokeh serve nodes.py

2. note: Please ensure port 5006 is available. Once the Tornado web server is started, navigate to http://localhost:5006/nodes with your web browser to see the presentation

If 5006 port is not available, please pick a port that is available, then issue the following command

bokeh serve nodes.py --port yourPort#

