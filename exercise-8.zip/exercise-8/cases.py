
from bokeh.io import curdoc
import numpy as np
import pandas as pd
from bokeh.plotting import figure
from bokeh.sampledata.us_counties import data as counties
from bokeh.models import ColumnDataSource, HoverTool, LogColorMapper, ColorBar, LogTicker, LabelSet
from bokeh.palettes import Blues6 as palette
#from bokeh.palettes import YlGnBu6 as palette
#from bokeh.palettes import Reds6 as palette
#from bokeh.palettes import Viridis6 as palette
from bokeh.layouts import row, widgetbox
from bokeh.models import CustomJS, Slider, Toggle

palette.reverse()

virus_file = "./data/West_Nile_Virus_by_County.json"
virusdf = pd.read_json(virus_file).set_index('County')

included = ["ca"]

counties = {
    code: county for code, county in counties.items() if county["state"] in included
}

county_xs = [county["lons"] for county in counties.values()]
county_ys = [county["lats"] for county in counties.values()]

county_names = [county['name'] for county in counties.values()]

cases_per_years = {}

def get_cases(counties, year):
    cases_reported = []

    for county_id in counties:
        if counties[county_id]["state"] not in included:
            continue
        try:
            countyid = county_id[0] * 1000 + county_id[1]
            cases = virusdf[(virusdf['id'] == countyid) & (virusdf['Year'] == year)]['Positive_Cases'].sum()

            if np.isnan(cases):
                cases = 0

            cases_reported.append(cases)
        except KeyError:
            dummy = 1
            
    return cases_reported

color_mapper = LogColorMapper(palette=palette)
minyear = virusdf["Year"].min()
maxyear = virusdf["Year"].max()
init_year = minyear


for y in np.arange(minyear, maxyear+1):
    cases_per_years[str(y)] = get_cases(counties, y)


data = dict(x=county_xs, y=county_ys, names=county_names, cases=cases_per_years[str(init_year)], **cases_per_years)
source = ColumnDataSource(data)


TOOLS = "pan,wheel_zoom,reset,hover,save"

p = figure(
    title="West Nile Virus in California", tools=TOOLS,
    x_axis_location=None, y_axis_location=None,
    plot_width=1100, plot_height=1000
)

hover = p.select_one(HoverTool)
hover.point_policy = "follow_mouse"
hover.tooltips = [("Name", "@names"), ("Virus cases)", "@cases"), ("(Long, Lat)", "($x, $y)"),]

p.grid.grid_line_color = None

labels = LabelSet(x='x', y='y', text='names', level='glyph',
                  source=source, text_font_size="500pt", render_mode='canvas',
                  x_offset=50, y_offset=50,
                  text_color="red", text_align="center")

#p.renderers.append(labels)
p.add_layout(labels)
p.patches('x', 'y', source=source, #legend='names',
          fill_color={'field': 'cases', 'transform': color_mapper},
          fill_alpha=1, line_color="black", line_width=0.5)

years = Slider(start=minyear, end=maxyear, value=minyear, step=1,
               title="Positive Cases Reported from {0} to {1}".format(minyear, maxyear))

# add button with callback to control animation
callback = CustomJS(args=dict(p=p, source=source), code="""
        var data = source.data;
        var f = cb_obj.active;
        var minyear = 2006;
        var maxyear = 2016;
        var j = minyear;
        var title = "Positive West Nile Virus Cases per County in period: ";

        if (f) {
            mytimer = setInterval(replace_data, 600);
        } else {
            clearInterval(mytimer);
        }

        p.title.text = "West Nile Virus in California";

        function reset() {
             j = minyear;
             data['cases'] = data[j];
        }

        function replace_data() {
             if (cb_obj.active === false) {
                 reset();
                 return;
             }

             if (j === minyear) {
                 p.title.text = null;
                 reset();
             }

             p.title.text = title + j;
             data['cases'] = data[j];
             j++;

             if (j === maxyear) {
                 j = minyear;
             }

             source.change.emit();
        }
        """)

btn = Toggle(label="Play/Stop Animation", button_type="success", active=False, callback=callback)

def update_data(attrname, old, new):
    btn.active = False
    data = source.data
    year = years.value

    p.title.text = "Positive West Nile Virus Cases per County in period: {0}".format(year)
    data['cases'] = data[str(year)]
    source.trigger('selected', None, None)

for w in [years]:
    w.on_change('value', update_data)

color_bar = ColorBar(color_mapper=color_mapper, ticker=LogTicker(),
                     label_standoff=12, border_line_color=None, location=(0,0))

inputs = widgetbox(btn,years,width=300)
p.add_layout(color_bar, 'right')
curdoc().add_root(row(inputs, p, width=1000))
curdoc().title = "West Nile Virus"
