From terminal, issue the following command from this root folder to start the lightweight web server that comes with python 2.7
note: Please ensure port 8000 is available.  Once the web server is started, navigate to http://localhost:8000 with your web browser to see the presentation

python -m SimpleHTTPServer 
